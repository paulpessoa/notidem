# HANDOFF — Comment Copilot for LinkedIn (leia isto primeiro, Claude)

Este documento existe para que, num **novo chat**, você (Claude) retome o projeto
sem precisar refazer descobertas. O usuário (Paul) vai carregar o zip inteiro.
Leia este arquivo antes de qualquer coisa.

## O que é o projeto
Extensão Chrome (Manifest V3) que gera comentários de LinkedIn com IA, usando o
perfil do próprio usuário como voz e a chave de API dele (BYOK). Provedores:
Groq (padrão, grátis), OpenAI, Gemini, Claude. Tudo client-side, sem servidor,
sem tracking. Pasta raiz da extensão: `copilot-ext/`.

## Estado atual (FUNCIONANDO)
- Carrega no Chrome sem erros, service worker ativo.
- Botão "✦ Comment Copilot" injeta na caixa de comentário do LinkedIn.
- Gera comentário com a chave Groq do usuário.
- Lê o texto do post corretamente.
- Insere o texto no campo de comentário.

## Descobertas CRÍTICAS já feitas (não repetir do zero)
1. **O LinkedIn migrou o editor de comentário de Quill para TipTap/ProseMirror.**
   - O editor agora é `div.ProseMirror[contenteditable="true"]` (antes era `.ql-editor`).
   - Confirmado via console: `editableInfo: ["DIV.tiptap ProseMirror ..."]`.
   - `findEditors()` em `src/content.js` já mira `.ProseMirror` primeiro.
2. **As classes de wrapper do LinkedIn são ofuscadas e voláteis** (ex: container
   apareceu como `_822ceebb`). NÃO depender de nomes de classe fixos.
   - `findPostContainer()` sobe a árvore por seletores + fallback de N níveis.
   - `longestTextBlock()` pega o maior bloco de texto do container (robusto).
3. **Inserção no ProseMirror** não funciona com `execCommand` sozinho. `insert()`
   usa evento de `paste` sintético (ClipboardEvent + DataTransfer) como estratégia
   primária, com execCommand e textContent como fallbacks.
4. O erro `chrome-extension://invalid/` que o usuário viu **NÃO é desta extensão** —
   é de outra extensão instalada. Ignorar.

## Ajustes finos PENDENTES (próximos passos sugeridos)
1. **Filtrar o headline do autor**: `longestTextBlock`/extração às vezes inclui o
   cargo do autor ("Professor | Diretor | ...") como primeiro bloco. O texto do
   post costuma ser o maior bloco, então na prática funciona, mas dá pra excluir
   explicitamente elementos dentro de `.update-components-actor` (área do autor).
2. **Ignorar lixo de acessibilidade**: aparece um bloco
   "Beginning of dialog window. Escape will cancel..." — filtrar por essa string
   ou por elementos com `role="dialog"`/`.visually-hidden`.
3. **Extrair autor de forma mais confiável**: hoje `postAuthor` usa seletores
   `.update-components-actor__*` que podem mudar. Validar e adicionar fallback.
4. (Opcional) Detectar quando o post é uma VAGA e ajustar o tom.

## Como o prompt está montado (já corrigido)
`src/lib/prompt.js` deixa explícito que há DOIS papéis: o USER (quem comenta, perfil
usado só como voz) e o POST AUTHOR (a quem o comentário responde). Isso corrigiu o
bug de "falar consigo mesmo". Se mexer no tom, manter essa separação.

## Arquitetura (para orientar edições)
```
copilot-ext/
├── manifest.json          MV3. Permissões: storage + 4 hosts de API. SEM activeTab/scripting.
├── src/
│   ├── background.js       service worker (ES module). Única camada de rede. Roteia mensagens, chama providers.
│   ├── content.js          IIFE (sem imports). Injeta botão, lê post, abre painel, insere texto. <-- ONDE MEXER NO DOM
│   ├── lib/
│   │   ├── storage.js       wrapper de chrome.storage.local
│   │   ├── prompt.js        montagem de prompt (system + user) <-- ONDE MEXER NO TOM
│   │   └── messages.js      constantes de mensagem
│   ├── providers/
│   │   ├── registry.js      metadados dos 4 providers (modelos, URLs de chave)
│   │   └── clients.js       um fetch client por provider, interface unificada
│   └── ui/
│       ├── tokens.css       design system + @font-face (Bricolage Grotesque + Spline Sans, bundladas)
│       ├── popup.html/.css/.js
│       ├── options.html/.css/.js   abas: Profile, API Keys, Preferences, History
│       └── content.css      estilos injetados no LinkedIn (prefixo .cc-)
├── vendor/                 pdf.min.js + pdf.worker.min.js (bundlados, sem CDN — exigência do review)
├── assets/icons|fonts
├── docs/                   PRIVACY.md, PERMISSIONS.md, PUBLISHING.md
└── store-assets/           screenshots 1280x800 + promo tiles (440x280, 1400x560) + store icon
```

## Como TESTAR localmente (passo a passo para passar ao usuário)
1. Extrair o zip. `chrome://extensions` → Modo desenvolvedor ON → "Carregar sem
   compactação" → selecionar a pasta `copilot-ext`.
2. Opções da extensão → aba API Keys: colar chave Groq (console.groq.com/keys) →
   Save. Aba Profile: escrever sobre si + tom → Save.
3. LinkedIn → abrir post → Comentar → botão "✦ Comment Copilot" → Generate → Insert.
4. Após editar código: ícone recarregar (🔄) no card + F5 no LinkedIn.

## Comando de diagnóstico de DOM (usar quando algo não casar)
Rodar no console do LinkedIn com a caixa de comentário aberta:
```javascript
(() => {
  const r = {};
  r.proseMirror = document.querySelectorAll('div.ProseMirror[contenteditable="true"]').length;
  r.qlEditors = document.querySelectorAll('.ql-editor').length;
  r.copilotButtons = document.querySelectorAll('.cc-trigger').length;
  const ed = document.querySelector('div.ProseMirror[contenteditable="true"]');
  let c = ed; for (let i=0;i<12&&c&&c.parentElement;i++){c=c.parentElement;
    if(c.matches('.feed-shared-update-v2,.fie-impression-container,[data-urn],article'))break;}
  r.container = c ? c.className.slice(0,40) : null;
  r.blocks = c ? [...c.querySelectorAll('span[dir="ltr"],p')].map(n=>(n.innerText||'').trim()).filter(t=>t.length>25).slice(0,6) : [];
  return JSON.stringify(r,null,2);
})()
```

## Publicação na Chrome Web Store
Ver `docs/PUBLISHING.md` (passo a passo completo, já verificado):
taxa única US$5, screenshots 1280x800, tiles 440x280 e 1400x560, zipar o CONTEÚDO
(não a pasta), janela de 30 dias pós-aprovação. Privacy policy precisa de URL
público (GitHub Pages serve). Justificativas de permissão prontas em PERMISSIONS.md.

## Como reempacotar (quando terminar edições)
```bash
cd copilot-ext
# zip de upload para a loja (só conteúdo da extensão):
zip -r ../comment-copilot.zip manifest.json src vendor assets -x "*.DS_Store" "assets/icon-master.svg"
# zip do projeto completo (com docs e store-assets):
cd .. && zip -r comment-copilot-full-project.zip copilot-ext -x "*.DS_Store"
```

— Fim do handoff. Bom trabalho, futura instância. O essencial já funciona; foque
nos "ajustes finos pendentes" acima.
