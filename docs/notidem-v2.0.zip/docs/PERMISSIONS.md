# Permission Justifications

These are written to paste directly into the Chrome Web Store Developer Dashboard
("Privacy practices" tab). Each permission maps to a concrete, user-facing feature.

## `storage`
**Justification:**
Used to save the user's profile text, writing-tone notes, résumé text, chosen AI
provider, language preference, entered API keys, and a local history of generated
comments. All data is stored locally on the user's device via `chrome.storage.local`
and is never transmitted to the developer. Without this permission the extension
could not remember the user's settings between sessions.

## Host permission: `https://api.groq.com/*`
**Justification:**
Required to send the user's comment-generation request directly to the Groq API
when the user selects Groq as their AI provider. The request uses the user's own
API key. No data is sent here unless the user clicks "Generate" with Groq selected.

## Host permission: `https://api.openai.com/*`
**Justification:**
Required to send comment-generation requests directly to the OpenAI API when the
user selects OpenAI as their provider, authenticated with the user's own API key.

## Host permission: `https://generativelanguage.googleapis.com/*`
**Justification:**
Required to send comment-generation requests directly to the Google Gemini API when
the user selects Gemini as their provider, authenticated with the user's own API key.

## Host permission: `https://api.anthropic.com/*`
**Justification:**
Required to send comment-generation requests directly to the Anthropic (Claude) API
when the user selects Claude as their provider, authenticated with the user's own API key.

## Content script on `https://www.linkedin.com/*`
**Justification:**
The core feature of the extension is helping users draft comments on LinkedIn posts.
The content script adds a "Comment Copilot" button beside LinkedIn comment boxes,
reads the text of the post the user wants to comment on, and inserts the approved
draft back into the comment field. It runs only on linkedin.com and performs no
tracking.

## Single purpose statement
**Comment Copilot for LinkedIn has one purpose:** to help a user draft and insert
AI-generated comments on LinkedIn posts, written in the user's own voice, using an
AI provider and API key supplied by the user.

## Remote code
This extension does **not** use remote code. All JavaScript, including the bundled
PDF text-extraction library (PDF.js), ships inside the package. No `<script>` tags
point to external URLs, and no code is fetched or `eval`'d at runtime.

## Data usage disclosures (check these boxes in the dashboard)
- [x] This item collects: "Personally identifiable information" (the profile/résumé
      text the user chooses to enter) and "Authentication information" (API keys) —
      **stored locally only**.
- [x] I do not sell or transfer user data to third parties, apart from the approved
      use case (sending prompts to the user's selected AI provider at the user's request).
- [x] I do not use or transfer user data for purposes unrelated to the item's single purpose.
- [x] I do not use or transfer user data to determine creditworthiness or for lending.
