# Publishing to the Chrome Web Store — Step by Step

This is the full, ordered checklist to get **Comment Copilot for LinkedIn** approved.
Following it in order is the difference between a 2-day approval and a multi-week
rejection loop. Everything you need (privacy policy, permission justifications,
icons, promo tiles, screenshots) is already in this repo.

---

## 0. Before you start — the 5 things reviewers reject for

Based on current Chrome Web Store policy, first-time rejections almost always come
from one of these. This project is already built to pass all five, but verify:

| Rejection trigger | How this project avoids it |
|---|---|
| Unused / overly broad permissions | Only `storage` + 4 specific API hosts. No `activeTab`, no `scripting`, no `<all_urls>`. |
| Missing / vague privacy policy | `docs/PRIVACY.md` is ready to host. |
| Remote code (MV3 violation) | PDF.js is bundled in `vendor/`. Nothing is fetched or `eval`'d. |
| Vague single-purpose statement | See the exact text in `docs/PERMISSIONS.md`. |
| Listing description too generic | Use the description text below — specific, not "makes life easier". |

---

## 1. One-time setup (~10 min)

1. Host the privacy policy at a public URL. Easiest free options:
   - Push this repo to GitHub and enable **GitHub Pages**, then link to
     `https://<you>.github.io/<repo>/docs/PRIVACY.md`, **or**
   - Paste `docs/PRIVACY.md` into a public Notion / Google Doc and use that URL.
   - You need a working public link before submitting.

2. Register as a Chrome Web Store developer:
   - Go to the **Chrome Web Store Developer Dashboard**.
   - Sign in with the Google account you want to own the extension.
   - Pay the **one-time $5 USD registration fee** (this is the only fee Google charges).
   - First-time accounts can take 7–14 days to build trust on the *first* submission;
     later updates review in ~24–48h.

---

## 2. Package the extension (~2 min)

The dashboard wants a ZIP of the extension **contents** — not the parent folder.

From inside the `copilot-ext/` directory:

```bash
# macOS / Linux
zip -r ../comment-copilot.zip . -x ".*" -x "store-assets/*" -x "docs/*" -x "README.md"
```

> Exclude `store-assets/`, `docs/`, and `README.md` — they don't need to ship inside
> the extension. They're for you and for the listing page. (The PRIVACY link in the
> options footer points to a hosted URL in production; the local file is just a dev
> convenience.)

What MUST be in the zip: `manifest.json`, `src/`, `vendor/`, `assets/`.

> On Windows: open the folder, select `manifest.json`, `src`, `vendor`, `assets`,
> right-click → *Send to → Compressed (zipped) folder*. Do **not** zip the outer
> `copilot-ext` folder itself.

---

## 3. Create the listing

In the dashboard, click **New Item** and upload `comment-copilot.zip`.
Then fill in each tab.

### Store listing tab

**Name:** Comment Copilot for LinkedIn

**Summary (132 chars max):**
> Draft thoughtful LinkedIn comments with AI, written in your own voice — using your own profile and your own API key.

**Description:** (specific and feature-led — paste this)
```
Comment Copilot helps you write thoughtful, on-brand comments on LinkedIn posts
in seconds — without sounding like a bot.

HOW IT WORKS
• Open any LinkedIn post and click the "Comment Copilot" button under the comment box.
• It reads the post and drafts a comment in YOUR voice, based on a profile you control.
• Regenerate, edit, and insert the comment with one click.
• A toolbar popup does the same thing from anywhere on LinkedIn.

YOU ARE IN CONTROL
• Bring your own API key — Groq (free tier), OpenAI, Google Gemini, or Anthropic Claude.
• Add your background by typing it or uploading a résumé PDF (parsed on your device).
• Set your preferred tone and the language comments are written in.
• Every draft is saved to a local history with a link back to the original post.

PRIVACY FIRST
• No accounts. No servers run by us. No tracking or ads.
• Everything is stored locally in your browser.
• Requests go directly to the AI provider you choose, using your key — nowhere else.

Comment Copilot is for professionals who want to engage genuinely on LinkedIn and
save time doing it.
```

**Category:** Productivity
**Language:** English

### Privacy practices tab (the one reviewers read closely)

- **Single purpose:** paste the single-purpose statement from `docs/PERMISSIONS.md`.
- **Permission justifications:** paste each block from `docs/PERMISSIONS.md`
  (`storage` + each host permission + the linkedin.com content script).
- **Privacy policy URL:** the public link you created in step 1.
- **Data usage:** check the boxes exactly as listed at the bottom of `docs/PERMISSIONS.md`:
  - Collects PII (profile/résumé text) and auth info (API keys) — stored locally.
  - Not sold or transferred to third parties beyond the user's chosen AI provider.
  - Not used for unrelated purposes, creditworthiness, or lending.

### Graphic assets tab

All of these are pre-made in `store-assets/`:

| Asset | File | Size |
|---|---|---|
| Store icon | `store-icon-128.png` | 128×128 |
| Screenshot 1 | `screenshot-1-profile.png` | 1280×800 |
| Screenshot 2 | `screenshot-2-keys.png` | 1280×800 |
| Screenshot 3 | `screenshot-3-popup.png` | 1280×800 |
| Screenshot 4 | `screenshot-4-linkedin.png` | 1280×800 |
| Small promo tile | `promo-small-440x280.png` | 440×280 |
| Marquee promo tile | `promo-marquee-1400x560.png` | 1400×560 |

> At least one 1280×800 screenshot is required (we provide four). The small promo
> tile is required. The marquee is optional but needed to be eligible for featuring.

---

## 4. Submit

1. Click **Submit for review**.
2. In the confirmation dialog you can choose to publish automatically once approved,
   or defer. For a first launch, deferring lets you double-check the live listing.
3. **Note:** after review completes you have **up to 30 days** to publish before the
   submission reverts to a draft.

---

## 5. After approval

- Test the live version end-to-end: install from the store, set a key, comment on a post.
- For updates: bump `"version"` in `manifest.json` (e.g. `1.0.0` → `1.0.1`), re-zip,
  upload to the same item. Updates review much faster than the first submission.

---

## 6. Promotion ideas (you asked about standing out)

- **A 30–45s demo video** of the LinkedIn flow → add the YouTube link to the listing;
  listings with video convert better and become marquee-eligible.
- **A LinkedIn post about it** — meta, and the perfect audience. Show the before/after
  of a generic comment vs. a Copilot-drafted one.
- **Free tier framing:** lead with "works free with a Groq key" — removes the cost
  objection at install time.
- **Open-source the repo** and link it from the listing; transparency is a selling
  point for a privacy-first tool and builds reviewer + user trust.

---

## Quick reference: facts verified for this guide

- Developer registration: one-time $5 USD.
- Screenshots: 1280×800 (preferred) or 640×400; up to 5.
- Promo tiles: small 440×280, marquee 1400×560.
- Zip the **contents**, not the folder.
- 128×128 icon should have ~96×96 of artwork with transparent padding (this repo's icon already does).
- No remote code in MV3 — all logic must ship in the package.
- Privacy policy URL is mandatory because the extension stores user-entered data.
