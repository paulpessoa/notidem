# Privacy Policy — Comment Copilot for LinkedIn

_Last updated: 2026_

Comment Copilot for LinkedIn ("the extension") is designed around a simple principle: **your data stays with you.** This policy explains exactly what the extension does and does not do with your information.

## Summary

- The extension does **not** have its own servers.
- The extension does **not** collect, transmit, sell, or share your personal data with the developer or any third party for analytics, advertising, or any other purpose.
- Everything you enter is stored **locally in your browser** using the Chrome `storage` API.
- The only outbound network requests go **directly** to the AI provider you choose (Groq, OpenAI, Google Gemini, or Anthropic), using **your own API key**.

## What the extension stores locally

All of the following is saved only on your device, in your browser's extension storage:

| Data | Purpose | Where it lives |
|------|---------|----------------|
| Profile text you type | Gives the AI context to write as you | Local browser storage |
| Résumé text extracted from a PDF you upload | Same as above | Local browser storage |
| Voice / tone notes | Shapes the writing style | Local browser storage |
| API keys you enter | Authenticates requests to your chosen AI provider | Local browser storage |
| Generated comment history | Lets you review and reuse past drafts | Local browser storage |
| Preferences (provider, language) | Remembers your settings | Local browser storage |

The PDF you upload is parsed **entirely on your device**. The file itself is never uploaded anywhere; only the extracted text is stored locally, and only to be included in prompts you explicitly trigger.

## What is sent over the network, and to whom

When you click **Generate**, the extension sends a single request to the AI provider you selected. That request contains:

- The text of the LinkedIn post you chose to comment on.
- Your profile/tone text (so the comment sounds like you).
- Your API key, used as the authentication header for that provider.

This request goes **directly from your browser to the provider's API**. It does not pass through any server controlled by the developer. Your use of each provider is governed by that provider's own privacy policy and terms:

- Groq — https://groq.com/privacy-policy/
- OpenAI — https://openai.com/policies/privacy-policy
- Google Gemini — https://ai.google.dev/gemini-api/terms
- Anthropic (Claude) — https://www.anthropic.com/legal/privacy

## What the extension does NOT do

- It does not read or store your LinkedIn messages, connections, or account credentials.
- It does not track your browsing activity.
- It does not contain analytics, telemetry, or advertising code.
- It does not load or execute any remote code. All logic ships inside the extension package.

## Permissions

The extension requests the minimum permissions required to function. See `PERMISSIONS.md` for a line-by-line justification.

## Data deletion

You can erase everything at any time: open the extension's **Settings → Preferences → Clear all data**. Uninstalling the extension also removes all locally stored data.

## Contact

Questions about this policy can be directed to the developer through the Chrome Web Store listing's support contact.
