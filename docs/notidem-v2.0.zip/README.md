# Comment Copilot for LinkedIn

Draft thoughtful, on-brand LinkedIn comments with AI — using **your** profile and
**your own** API key. No accounts, no servers, no tracking.

![icon](assets/icons/icon128.png)

## What it does

- Adds a **Comment Copilot** button next to any LinkedIn comment box.
- Reads the post you're replying to and drafts a comment in your voice.
- Lets you **regenerate**, edit, and then **insert** the comment in one click.
- Works from the toolbar **popup** too.
- Keeps a local **history** of everything you've drafted, with quick links back to the post.
- Supports four providers — **Groq, OpenAI, Gemini, Claude** — all bring-your-own-key.

Everything is stored locally. The only network calls go straight to the AI provider
you pick. See [`docs/PRIVACY.md`](docs/PRIVACY.md).

## Project structure

```
comment-copilot/
├── manifest.json              # MV3 manifest, minimal permissions
├── assets/
│   ├── icons/                 # 16/32/48/128 PNG icons
│   └── fonts/                 # Bricolage Grotesque + Spline Sans (bundled, woff2)
├── vendor/
│   ├── pdf.min.js             # PDF.js (bundled, not remote) — Apache-2.0
│   └── pdf.worker.min.js
├── src/
│   ├── background.js          # Service worker: routing + provider calls
│   ├── content.js             # LinkedIn injection: button, panel, insert
│   ├── lib/
│   │   ├── storage.js         # Typed wrapper over chrome.storage.local
│   │   ├── prompt.js          # Pure prompt-building functions
│   │   └── messages.js        # Shared message-type constants
│   ├── providers/
│   │   ├── registry.js        # Provider metadata (models, key URLs)
│   │   └── clients.js         # One fetch client per provider
│   └── ui/
│       ├── tokens.css         # Shared design system + @font-face
│       ├── popup.html/.css/.js
│       ├── options.html/.css/.js
│       └── content.css        # Styles injected into LinkedIn
└── docs/
    ├── PRIVACY.md
    ├── PERMISSIONS.md
    └── PUBLISHING.md           # Step-by-step Chrome Web Store guide
```

## Architecture notes

- **Service worker** (`background.js`) is the only place that performs network
  requests, so content scripts never fight CORS. It's an ES module (`"type": "module"`).
- **Content script** is intentionally *not* a module (declared content scripts have
  patchy module support), so it's a self-contained IIFE with inlined message constants.
- **UI pages** (popup, options) *are* ES modules and import shared `lib/` and
  `providers/` code — no duplication.
- **PDF parsing** runs on-device via bundled PDF.js. The worker is exposed to the
  options page (an extension page) and declared in `web_accessible_resources` for
  the linkedin.com surface.
- **No build step.** The folder loads as-is via *Load unpacked*. This keeps the
  source fully auditable, which is exactly what the Web Store review wants.

## Local development

1. Open `chrome://extensions`.
2. Toggle **Developer mode** (top-right).
3. Click **Load unpacked** and select this folder.
4. Open the extension's **Settings**, add your profile and at least one API key
   (Groq has a free tier — https://console.groq.com/keys).
5. Go to LinkedIn, open a post, click **✦ Comment Copilot** under the comment box.

After editing files, click the **reload** icon on the extension card to apply changes.

## Publishing

See [`docs/PUBLISHING.md`](docs/PUBLISHING.md) for the full, ordered checklist to get
approved on the Chrome Web Store.

## Third-party licenses

- **PDF.js** — Apache License 2.0 — https://github.com/mozilla/pdf.js
- **Bricolage Grotesque** — SIL Open Font License 1.1
- **Spline Sans** — SIL Open Font License 1.1

## License

MIT (your project code). Bundled assets retain their own licenses noted above.
